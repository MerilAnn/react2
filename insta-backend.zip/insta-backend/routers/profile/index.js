const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../../models/User');
const Auth = require('../../libs/Auth');
const jwt  = require('jsonwebtoken');
const Follow = require('../../models/Follow');
const router = express.Router();

const saltRounds = 10;

router.get('/', Auth.isLoggedIn, async(req, res) => {
//    let header = req.headers.authorization
//    //console.log('hhh', header.authorization);
//    let token = req.headers.authorization.split(' ')[1]
//    console.log('token',token);
//    jwt.verify(token, process.env.AUTH_SECRET_KEY, async function(err, decoded){
//     if(err){
//         return res.status(401).json({message: 'Auth Failed'})
//     }
//     console.log(decoded);
//     let user = await User.findById(decoded.userId, 'fullName username email');
//     return res.json({user})
//    });
return res.json({ user: req.user})
})

router.put('/', Auth.isLoggedIn, async (req, res) => {
    let { fullName, email, username } = req.body;
    let user = req.user;
    if (fullName) {
        user.fullName = fullName
    } if (email) {
        let validateEmail = await User.findOne({email})
        if(validateEmail){
            return res.status(400).json({message: "Email already exists"})
        }
        user.email = email
    }
    if (username) {
        let validateUsername = await User.findOne({username})
        if(validateUsername){
            return res.status(400).json({message: "Username already exists"})
        }
        user.username = username
    }
user.save().then(() => {
    return res.json({message:"Profile Updated"})
})

})

router.post('/follow', Auth.isLoggedIn, async(req, res) => {
    let { followingTo } = req.body;
    let checkFollow = await Follow.findOne({
followingTo,
followingBy: req.user
    })
    if(checkFollow){
        return res.status(403).json({message:"You are already following this account"})
    }
    Follow.create({
        followingTo,
followingBy: req.user
    }).then(() => {
        return res.json({message:"You have followed"})
    })
})

router.get('/list/following', Auth.isLoggedIn, async(req, res) => {
    let following = await Follow.find({followingBy: req.user}).populate('followingTo','fullName username email')
    return res.json({ following})
})

router.get('/list/followers', Auth.isLoggedIn, async(req, res) => {
    let followers = await Follow.find({followingTo: req.user}).populate('followingBy','fullName username email')
    return res.json({ followers})
})

module.exports = router;