const bodyParser = require('body-parser')
const express = require('express')
const app = express()
require('dotenv').config()
const mongoose = require('mongoose')

app.use(bodyParser.json())

main().catch(err => console.log(err));

require('./models/User');
require('./models/Post');
require('./models/Follow');
require('./models/Like');
require('./models/Comment');

app.use('/',require('./routers'))

async function main(){
    await mongoose.connect('mongodb+srv://ann:ann@cluster1.xcurc.mongodb.net/?retryWrites=true&w=majority', { dbName: "insta-backend" });
    console.log('DB Connected');
}

app.get('/', function (req, res) {
  res.send('Hello World')
})

app.listen(process.env.PORT, () => {
    console.log('Insta backend is running at PORT : '+process.env.PORT);
});